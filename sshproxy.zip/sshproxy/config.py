import os

def load_env_config():
    return {
        "host": os.environ.get("HOSTIP"),
        "user": os.environ.get("USERNAME"),
        "mode": int(os.environ.get("MODE", 0)),
        "port": int(os.environ.get("PORT", 22)),
    }
