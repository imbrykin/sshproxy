import os
import logging

logger = logging.getLogger(__name__)


def start_session(host: str, user: str, mode: int, port: int):
    from sshproxy.ipa import check_access
    from sshproxy.ssh import run_ssh_session, run_sftp_proxy

    allowed = check_access(user, host)

    if allowed:
        logger.info(f"Access GRANTED for {user}@{host}")
    else:
        logger.warning(f"Access DENIED for {user}@{host}")
        return

    logger.info(f"Session starting: {user}@{host}:{port} [mode={mode}]")

    if mode == 0:
        run_ssh_session(user, host, port)
    elif mode == 1:
        run_sftp_proxy(user, host, port)
    else:
        logger.error("Unknown mode: %s", mode)