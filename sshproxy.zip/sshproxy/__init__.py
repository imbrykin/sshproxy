# sshproxy/__init__.py

"""
SSHProxy - Lightweight SSH/SFTP proxy with FreeIPA-based authorization
"""

__version__ = "0.1.0"
__author__ = "Ivan Brykin"